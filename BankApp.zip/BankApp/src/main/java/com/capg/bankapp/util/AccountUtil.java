package com.capg.bankapp.util;

public class AccountUtil {

	public static int generateAccountNo() {
		return 123;
		//return (int)Math.random()*100;
	}
}
