package com.capg.bankapp.dao;

import com.capg.bankapp.model.Account;

public class AccountDaoImpl implements IAccountDao{

	@Override
	public boolean saveAccount(Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Account findAccount(int accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

}
